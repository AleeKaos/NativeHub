package com.example.nativehub

import android.app.Application
import android.os.Build
import android.webkit.WebView

/**
 * setDataDirectorySuffix() só pode ser chamado UMA VEZ por processo,
 * e antes de qualquer WebView existir naquele processo.
 * É por isso que chamar ele dentro de cada WebView (como no código antigo)
 * não funciona: na 2ª aba ele já dá IllegalStateException ("WebView already initialized").
 *
 * A solução é chamar aqui, no Application, que roda uma vez em CADA processo
 * (o principal + tab2, tab3... tab15) antes de qualquer Activity ou WebView.
 * Cada processo então usa uma pasta de dados diferente = cookies, localStorage,
 * cache etc. totalmente isolados entre as abas.
 */
class NativeHubApplication : Application() {

    override fun onCreate() {
        super.onCreate()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            val processName = getProcessName()
            // O processo principal (sem ":tabN") usa o diretório padrão, sem sufixo
            if (processName != packageName) {
                try {
                    WebView.setDataDirectorySuffix(processName)
                } catch (e: IllegalStateException) {
                    // Já foi definido para este processo (ex: Activity recriada por rotação
                    // de tela) - pode ignorar com segurança.
                }
            }
        }
        // Em Android < 9 (API 28) não existe forma de isolar WebViews por processo;
        // o app funciona, mas as abas passam a compartilhar os mesmos dados.
    }
}