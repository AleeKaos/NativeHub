package com.example.nativehub

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp

class SettingsActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            MaterialTheme {
                Surface(
                    modifier = Modifier.fillMaxSize()
                ) {
                    SettingsScreen()
                }
            }
        }
    }
}

@Composable
private fun SettingsScreen() {

    val context = LocalContext.current

    var sites by remember {
        mutableStateOf(PrefsHelper.getSites(context))
    }

    var showDialog by remember {
        mutableStateOf(false)
    }

    var siteName by remember {
        mutableStateOf("")
    }

    var siteUrl by remember {
        mutableStateOf("")
    }

    if (showDialog) {

        AlertDialog(
            onDismissRequest = {
                showDialog = false
            },

            title = {
                Text("Adicionar Site")
            },

            text = {

                Column {

                    OutlinedTextField(
                        value = siteName,
                        onValueChange = {
                            siteName = it
                        },
                        label = {
                            Text("Nome")
                        },
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = siteUrl,
                        onValueChange = {
                            siteUrl = it
                        },
                        label = {
                            Text("URL")
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 8.dp)
                    )
                }
            },

            confirmButton = {

                Button(
                    onClick = {

                        if (
                            siteName.isNotBlank() &&
                            siteUrl.isNotBlank()
                        ) {

                            PrefsHelper.addSite(
                                context,
                                siteName,
                                siteUrl
                            )

                            sites =
                                PrefsHelper.getSites(context)

                            siteName = ""
                            siteUrl = ""
                            showDialog = false
                        }
                    }
                ) {
                    Text("Salvar")
                }
            },

            dismissButton = {

                TextButton(
                    onClick = {
                        showDialog = false
                    }
                ) {
                    Text("Cancelar")
                }
            }
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {

        Text(
            text = "Sites",
            style = MaterialTheme.typography.titleLarge
        )

        Button(
            onClick = {
                showDialog = true
            },
            modifier = Modifier.padding(top = 12.dp)
        ) {
            Text("+ Adicionar Site")
        }

        LazyColumn(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 16.dp)
        ) {

            itemsIndexed(sites) { index, site ->

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 6.dp),
                    horizontalArrangement =
                        Arrangement.SpaceBetween
                ) {

                    Text(site.name)

                    Button(
                        onClick = {

                            PrefsHelper.removeSite(
                                context,
                                index
                            )

                            sites =
                                PrefsHelper.getSites(context)
                        }
                    ) {
                        Text("Remover")
                    }
                }
            }
        }
    }
}